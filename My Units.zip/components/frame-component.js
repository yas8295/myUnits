import Image from "next/image";
import PropTypes from "prop-types";

const FrameComponent = ({ className = "", property1 = "Default" }) => {
  return (
    <button
      className={`cursor-pointer [border:none] py-[10px] px-[0px] bg-[transparent] w-[319px] flex flex-col items-center justify-center box-border ${className}`}
      data-property1={property1}
    >
      <button className="cursor-pointer [border:none] py-[16px] px-[24px] bg-[#6666ff] w-[295px] h-[52px] rounded-[10px] flex flex-row items-center justify-center box-border gap-[8px]">
        <Image
          className="w-[24px] relative h-[24px] hidden"
          width={24}
          height={24}
          alt=""
          src="/logo.svg"
        />
        <Image
          className="w-[24px] relative h-[24px] object-cover hidden"
          width={24}
          height={24}
          alt=""
          src="/logo1@2x.png"
        />
        <Image
          className="w-[24px] relative h-[24px] overflow-hidden shrink-0"
          width={24}
          height={24}
          alt=""
          src="/icroundadd.svg"
        />
        <div className="relative text-[16px] tracking-[0.01em] leading-[135%] font-semibold font-[Poppins] text-[#fff] text-center">
          Add Unit
        </div>
      </button>
    </button>
  );
};

FrameComponent.propTypes = {
  className: PropTypes.string,

  /** Variant props */
  property1: PropTypes.number,
};

export default FrameComponent;
