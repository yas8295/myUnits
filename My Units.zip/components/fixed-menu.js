import GroupComponent from "./group-component";
import PropTypes from "prop-types";

const FixedMenu = ({ className = "" }) => {
  return (
    <header
      className={`w-full h-[109px] !m-[0] absolute top-[0px] right-[0px] left-[0px] shadow-[0px_8px_14px_rgba(0,_0,_0,_0.05)] bg-[#fff] flex flex-col items-start justify-start py-[0px] px-[100px] box-border z-[1] text-left text-[20px] text-[#0512f5] font-[Poppins] ${className}`}
    >
      <GroupComponent />
    </header>
  );
};

FixedMenu.propTypes = {
  className: PropTypes.string,
};

export default FixedMenu;
