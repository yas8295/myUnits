import { useMemo } from "react";
import Image from "next/image";
import PropTypes from "prop-types";

const FrameComponent3 = ({
  className = "",
  property1 = "Default",
  frameDivWidth,
  home,
  line447,
}) => {
  const frameDiv2Style = useMemo(() => {
    return {
      width: frameDivWidth,
    };
  }, [frameDivWidth]);

  return (
    <div
      className={`w-[60px] h-[30px] overflow-hidden shrink-0 flex flex-col items-center justify-between text-left text-[20px] text-[#0512f5] font-[Poppins] ${className}`}
      data-property1={property1}
      style={frameDiv2Style}
    >
      <a className="[text-decoration:none] self-stretch relative capitalize font-medium text-[inherit]">
        {home}
      </a>
      <Image
        className="w-[4px] relative h-0"
        width={4}
        height
        alt=""
        src={line447}
      />
    </div>
  );
};

FrameComponent3.propTypes = {
  className: PropTypes.string,
  home: PropTypes.string,
  line447: PropTypes.string.isRequired,

  /** Variant props */
  property1: PropTypes.number,

  /** Style props */
  frameDivWidth: PropTypes.string,
};

export default FrameComponent3;
