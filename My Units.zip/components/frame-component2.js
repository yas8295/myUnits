import { useMemo } from "react";
import PropTypes from "prop-types";

const FrameComponent2 = ({
  className = "",
  dashboardSideMenu = "toogle",
  myAccount,
  myAccountWidth,
}) => {
  const myAccountStyle = useMemo(() => {
    return {
      width: myAccountWidth,
    };
  }, [myAccountWidth]);

  return (
    <div
      className={`w-[294px] h-[42px] rounded-[10px] bg-[#f2f3f4] overflow-hidden shrink-0 flex flex-row items-start justify-start py-[10px] px-[27px] box-border gap-[30px] text-left text-[16px] text-[#0512f5] font-[Poppins] ${className}`}
      data-dashboardSideMenu={dashboardSideMenu}
    >
      <div className="ml-[-40px] h-[16px] w-[10px] flex flex-col items-start justify-start pt-[6px] px-[0px] pb-[0px] box-border">
        <div className="w-[10px] h-[10px] relative rounded-[50%] bg-[#0512f5]" />
      </div>
      <div
        className="h-[22px] w-[91px] relative tracking-[-0.03em] leading-[140%] inline-block shrink-0"
        style={myAccountStyle}
      >
        {myAccount}
      </div>
    </div>
  );
};

FrameComponent2.propTypes = {
  className: PropTypes.string,
  myAccount: PropTypes.string,

  /** Variant props */
  dashboardSideMenu: PropTypes.number,

  /** Style props */
  myAccountWidth: PropTypes.string,
};

export default FrameComponent2;
