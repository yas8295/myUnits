import FrameComponent4 from "./frame-component4";
import PropTypes from "prop-types";

const FrameComponent5 = ({ className = "", loggedInOut = "logged out" }) => {
  return (
    <div
      className={`absolute top-[22px] left-[1045px] flex flex-row items-center justify-center p-[10px] text-left text-[16px] text-[#494949] font-[Poppins] ${className}`}
      data-loggedInOut={loggedInOut}
    >
      <FrameComponent4 logout="default" />
    </div>
  );
};

FrameComponent5.propTypes = {
  className: PropTypes.string,

  /** Variant props */
  loggedInOut: PropTypes.number,
};

export default FrameComponent5;
