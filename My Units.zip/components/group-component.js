import Image from "next/image";
import FrameComponent3 from "./frame-component3";
import LanguageSwitcher from "./language-switcher";
import FrameComponent5 from "./frame-component5";
import PropTypes from "prop-types";

const GroupComponent = ({ className = "" }) => {
  return (
    <div
      className={`w-[1250px] h-[109px] relative text-left text-[20px] text-[#0512f5] font-[Poppins] ${className}`}
    >
      <Image
        className="absolute top-[0px] left-[0px] w-[146px] h-[109px] overflow-hidden object-cover"
        loading="lazy"
        width={146}
        height={109}
        alt=""
        src="/logo@2x.png"
      />
      <div className="absolute top-[32px] left-[499px] flex flex-row items-center justify-start gap-[34px]">
        <FrameComponent3
          property1="Default"
          home="Home"
          line447="pending_I1:499;159:4618;105:3934"
        />
        <FrameComponent3
          property1="Default"
          frameDivWidth="61px"
          home="About"
          line447="pending_I1:499;159:4619;105:3934"
        />
        <FrameComponent3
          property1="Default"
          frameDivWidth="82px"
          home="Contact"
          line447="pending_I1:499;159:4620;105:3934"
        />
        <div className="overflow-hidden flex flex-row items-center justify-start gap-[4px]">
          <Image
            className="h-[28px] w-[28px] relative overflow-hidden shrink-0"
            loading="lazy"
            width={28}
            height={28}
            alt=""
            src="/marketeqfavourite.svg"
          />
          <a className="[text-decoration:none] relative capitalize font-medium text-[inherit]">
            Favourite
          </a>
        </div>
        <LanguageSwitcher switcher="english" />
      </div>
      <FrameComponent5 loggedInOut="logged in" />
    </div>
  );
};

GroupComponent.propTypes = {
  className: PropTypes.string,
};

export default GroupComponent;
