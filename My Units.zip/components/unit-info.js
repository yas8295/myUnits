import { useMemo } from "react";
import Image from "next/image";
import PropTypes from "prop-types";

const UnitInfo = ({
  className = "",
  frameDivBackgroundColor,
  approved,
  approvedDisplay,
  approvedMinWidth,
  asignABroker,
  asignABrokerFlex,
}) => {
  const frameDivStyle = useMemo(() => {
    return {
      backgroundColor: frameDivBackgroundColor,
    };
  }, [frameDivBackgroundColor]);

  const approvedStyle = useMemo(() => {
    return {
      display: approvedDisplay,
      minWidth: approvedMinWidth,
    };
  }, [approvedDisplay, approvedMinWidth]);

  const asignABrokerStyle = useMemo(() => {
    return {
      flex: asignABrokerFlex,
    };
  }, [asignABrokerFlex]);

  return (
    <div
      className={`flex-1 flex flex-col items-start justify-end pt-[0px] px-[0px] pb-[19px] box-border min-w-[370px] max-w-full text-left text-[16px] text-[#494949] font-[Poppins] mq450:min-w-full ${className}`}
    >
      <div className="self-stretch flex flex-col items-start justify-start gap-[5px] max-w-full">
        <div className="self-stretch flex flex-row items-start justify-start gap-[36px] max-w-full z-[1] text-[22px] text-[#000] mq700:gap-[18px] mq700:flex-wrap">
          <div className="flex-1 flex flex-row items-end justify-start gap-[11px] min-w-[230px] max-w-full mq450:flex-wrap">
            <h3 className="m-[0px] relative text-inherit capitalize font-medium font-[inherit] mq450:text-[18px]">
              Grand House Real Estate
            </h3>
            <div className="flex flex-col items-start justify-end pt-[0px] px-[0px] pb-[5px] text-[12px] text-[#fff]">
              <div
                className="rounded-[4px] bg-[#02ae36] flex flex-row items-start justify-start py-[2px] pl-[5px] pr-[4px]"
                style={frameDivStyle}
              >
                <div
                  className="relative capitalize font-medium inline-block min-w-[61px]"
                  style={approvedStyle}
                >
                  {approved}
                </div>
              </div>
            </div>
          </div>
          <div className="w-[180px] flex flex-row items-start justify-start py-[1.5px] px-[0px] box-border text-[28px] text-[#f20000]">
            <div className="ml-[-9.5px] h-[30px] relative capitalize flex items-center shrink-0 whitespace-nowrap mq450:text-[16px]">
              <span>
                <span className="font-semibold">13.500.000</span>
                <span className="text-[26px] font-medium">{` `}</span>
                <span className="text-[20px]">EGP</span>
              </span>
            </div>
          </div>
        </div>
        <div className="w-[305px] flex flex-col items-start justify-start pt-[0px] px-[0px] pb-[10px] box-border gap-[15px]">
          <div className="self-stretch relative capitalize font-medium z-[1]">
            New Cairo, Egypt
          </div>
          <div className="flex flex-row items-start justify-start gap-[20px] text-[12px]">
            <div className="flex flex-row items-start justify-start gap-[6px]">
              <Image
                className="h-[24px] w-[24px] relative rounded-[5px] overflow-hidden shrink-0 z-[1]"
                loading="lazy"
                width={24}
                height={24}
                alt=""
                src="/materialsymbolslightbedroomchildoutlinerounded.svg"
              />
              <div className="flex flex-col items-start justify-start pt-[2.5px] px-[0px] pb-[0px]">
                <div className="relative capitalize font-medium inline-block min-w-[54px] z-[1]">
                  3 Rooms
                </div>
              </div>
            </div>
            <div className="flex flex-row items-start justify-start gap-[6px]">
              <Image
                className="h-[24px] w-[24px] relative rounded-[5px] z-[1]"
                loading="lazy"
                width={24}
                height={24}
                alt=""
                src="/frame-49176.svg"
              />
              <div className="flex flex-col items-start justify-start pt-[2.5px] px-[0px] pb-[0px]">
                <div className="relative capitalize font-medium inline-block min-w-[75px] z-[1]">
                  3 Bathroom
                </div>
              </div>
            </div>
            <div className="flex flex-row items-start justify-start gap-[6px]">
              <Image
                className="h-[24px] w-[24px] relative rounded-[5px] overflow-hidden shrink-0 z-[1]"
                width={24}
                height={24}
                alt=""
                src="/tdesignmeasurement1.svg"
              />
              <div className="flex flex-col items-start justify-start pt-[2.5px] px-[0px] pb-[0px]">
                <div className="relative font-medium inline-block min-w-[42px] z-[1]">
                  <span className="capitalize">{`250 `}</span>m
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="self-stretch flex flex-row items-start justify-between py-[10px] px-[0px] gap-[20px] z-[1] mq450:flex-wrap">
          <button className="cursor-pointer border-[#6666ff] border-[1px] border-solid py-[13px] pl-[88px] pr-[85px] bg-[#fff] h-[52px] rounded-[10px] box-border flex flex-row items-start justify-center gap-[8px] mq450:pl-[20px] mq450:pr-[20px] mq450:box-border">
            <Image
              className="h-[24px] w-[24px] relative hidden"
              width={24}
              height={24}
              alt=""
              src="/logo2.svg"
            />
            <Image
              className="h-[24px] w-[24px] relative object-cover hidden"
              width={24}
              height={24}
              alt=""
              src="/logo3@2x.png"
            />
            <div
              className="relative text-[16px] tracking-[0.01em] leading-[135%] font-semibold font-[Poppins] text-[#6666ff] text-center"
              style={asignABrokerStyle}
            >
              {asignABroker}
            </div>
          </button>
          <div className="flex flex-col items-start justify-start pt-[4.5px] px-[0px] pb-[0px]">
            <div className="flex flex-col items-start justify-start gap-[5px]">
              <div className="flex flex-row items-start justify-start py-[0px] pl-[24px] pr-[0px]">
                <div className="relative capitalize font-medium inline-block min-w-[57px]">
                  Added
                </div>
              </div>
              <div className="relative capitalize inline-block min-w-[81px]">
                31/8/2022
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

UnitInfo.propTypes = {
  className: PropTypes.string,
  approved: PropTypes.string,
  asignABroker: PropTypes.string,

  /** Style props */
  frameDivBackgroundColor: PropTypes.string,
  approvedDisplay: PropTypes.string,
  approvedMinWidth: PropTypes.string,
  asignABrokerFlex: PropTypes.string,
};

export default UnitInfo;
