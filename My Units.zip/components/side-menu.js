import { useCallback } from "react";
import FrameComponent2 from "./frame-component2";
import { useRouter } from "next/router";
import PropTypes from "prop-types";

const SideMenu = ({ className = "" }) => {
  const router = useRouter();

  const onFrameContainerClick = useCallback(() => {
    router.push("/");
  }, [router]);

  return (
    <div
      className={`absolute top-[130px] left-[0px] w-[294px] h-[166px] flex flex-row items-start justify-start pt-[0px] px-[0px] pb-[14px] box-border text-left text-[16px] text-[#0512f5] font-[Poppins] ${className}`}
    >
      <div className="h-[152px] w-[294px] flex flex-col items-start justify-start gap-[13px]">
        <FrameComponent2 dashboardSideMenu="default" myAccount="My Account" />
        <div
          className="self-stretch rounded-[10px] bg-[#f2f3f4] border-[#0512f5] border-[1px] border-solid flex flex-row items-center justify-start py-[10px] pl-[24px] pr-[145px] gap-[5px] cursor-pointer"
          onClick={onFrameContainerClick}
        >
          <div className="h-[10px] w-[10px] relative rounded-[50%] bg-[#0512f5]" />
          <div className="relative tracking-[-0.03em] leading-[140%]">
            My Units
          </div>
        </div>
        <FrameComponent2
          dashboardSideMenu="default"
          myAccount="My Reservations"
          myAccountWidth="124px"
        />
      </div>
    </div>
  );
};

SideMenu.propTypes = {
  className: PropTypes.string,
};

export default SideMenu;
