import Image from "next/image";
import FrameComponent from "./frame-component";
import UnitInfo from "./unit-info";
import Filter from "./filter";
import PropTypes from "prop-types";

const FrameComponent6 = ({ className = "" }) => {
  return (
    <div
      className={`self-stretch flex flex-col items-end justify-start gap-[10px] max-w-full text-left text-[16px] text-[#494949] font-[Poppins] ${className}`}
    >
      <FrameComponent property1="Default" />
      <div className="self-stretch flex flex-row items-start justify-end py-[0px] pl-[0px] pr-[6px] box-border max-w-full">
        <div className="flex-1 shadow-[0px_30px_30px_-25px_rgba(0,_0,_0,_0.15)] rounded-[16px] bg-[#f2f3f4] flex flex-row items-end justify-center flex-wrap content-end relative gap-[21px] max-w-full">
          <div className="self-stretch w-[922px] relative shadow-[0px_30px_30px_-25px_rgba(0,_0,_0,_0.15)] rounded-[16px] bg-[#f2f3f4] hidden max-w-full z-[0]" />
          <Image
            className="h-[235px] w-[228px] relative rounded-tl-[16px] rounded-tr-[0px] rounded-br-[0px] rounded-bl-[16px] object-cover z-[1]"
            loading="lazy"
            width={228}
            height={235}
            alt=""
            src="/rectangle-20@2x.png"
          />
          <UnitInfo approved="Approved" asignABroker="Asign a Broker" />
          <Image
            className="h-[235px] w-[83px] relative z-[1]"
            loading="lazy"
            width={83}
            height={235}
            alt=""
            src="/group-120.svg"
          />
          <Filter property1="Variant2" />
        </div>
      </div>
    </div>
  );
};

FrameComponent6.propTypes = {
  className: PropTypes.string,
};

export default FrameComponent6;
