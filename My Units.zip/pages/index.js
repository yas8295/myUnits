import FrameComponent6 from "../components/frame-component6";
import UnitsList from "../components/units-list";
import FixedMenu from "../components/fixed-menu";
import Component2 from "../components/component2";
import Footer from "../components/footer";

const MyAccount = () => {
  return (
    <div className="relative bg-[#fff] w-full overflow-x-auto flex flex-col items-end justify-start pt-[147px] px-[0px] pb-[0px] box-border gap-[4px] leading-[normal] tracking-[normal]">
      <main className="w-[1121px] flex flex-row items-start justify-center py-[0px] px-[20px] box-border max-w-full">
        <section className="flex flex-col items-start justify-start gap-[40px] max-w-full mq450:gap-[20px]">
          <FrameComponent6 />
          <UnitsList />
        </section>
      </main>
      <FixedMenu />
      <Component2 property1="Variant2" />
      <Footer />
    </div>
  );
};

export default MyAccount;
